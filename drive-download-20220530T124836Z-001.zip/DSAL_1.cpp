// root --> left --> right  : preorder traversal
// left --> root --> right  : postorder traversal
// left --> right --> root  : inorder traversal

/* 1.Creation
   2.Traversal
   3.Copy
   4.Delete
   5.Mirror Image
   6.Height
   7.Count Leaf and Internal Nodes
*/

#include <iostream>
using namespace std;
#define SIZE 1000
//-----------------------------------------------------------------------------------------------------------------------//
int max(int a, int b) // for height of the tree
{
    if (a > b)
    {
        return a;
    }
    else
    {
        return b;
    }
}
//-----------------------------------------------------------------------------------------------------------------------//
template <class T>
class Stack // For Iterative Traversals
{
    friend class Node;
    friend class Tree;

public:
    Stack();
    void push(T k);
    T pop();
    T topElement();
    bool isFull();
    bool isEmpty();

private:
    int top;
    T st[SIZE];
};

template <class T>
Stack<T>::Stack() { top = -1; }

template <class T>
void Stack<T>::push(T k)
{
    if (isFull())
    {
        cout << "Stack is full\n";
    }
    top = top + 1;
    st[top] = k;
}

template <class T>
bool Stack<T>::isEmpty()
{
    if (top == -1)
        return 1;
    else
        return 0;
}

template <class T>
bool Stack<T>::isFull()
{
    if (top == (SIZE - 1))
        return 1;
    else
        return 0;
}

template <class T>
T Stack<T>::pop()
{
    T popped_element = st[top];
    top--;
    return popped_element;
}

template <class T>
T Stack<T>::topElement()
{
    T top_element = st[top];
    return top_element;
}

template <class X>
class Queue
{

private:
    int front;
    int rear;
    X *arr;
    int sizeVar;
    int capacityVar = 1000;

public:
    Queue()
    {
        arr = new X[capacityVar];
        front = rear = -1;
        sizeVar = 0;
    }

    bool empty();
    bool full();
    void push(X x);
    void pop();
    X front1();
    X back();
    int capacity();
    int size();
};

template <class X>
int Queue<X>::capacity()
{
    return capacityVar;
}

template <class X>
int Queue<X>::size()
{
    return sizeVar;
}
template <class X>
bool Queue<X>::empty()
{
    if (front == -1 && rear == -1)
        return true;
    else
        return false;
}
template <class X>
bool Queue<X>::full()
{
    if (sizeVar == capacityVar)
        return true;
    else
        return false;
}
template <class X>
X Queue<X>::front1()
{

    if (empty())
    {
        cout << "Queue underflow"
             << endl;
        abort();
    }

    return arr[front];
}

template <class X>
X Queue<X>::back()
{
    if (empty())
    {
        cout << "Queue underflow"
             << endl;
        abort();
    }
    return arr[rear];
}

template <class X>
void Queue<X>::push(X x)
{
    if (full())
    {
        capacityVar = capacityVar * 2;
        X *temp = new X[capacityVar];
        for (int i = 0; i < sizeVar; i++)
            temp[i] = arr[i];
        delete[] arr;
        arr = temp;
    }
    if (empty())
    {

        front = rear = 0;
        arr[rear] = x;
        sizeVar++;
        return;
    }
    rear = (rear + 1) % capacityVar;
    arr[rear] = x;
    sizeVar++;
    return;
}

template <class X>
void Queue<X>::pop()
{
    if (empty())
    {
        cout << "Queue underflow"
             << endl;
        abort();
    }
    if (front == rear)
    {
        front = rear = -1;
        sizeVar--;
        return;
    }

    front = (front + 1) % capacityVar;
    sizeVar--;
    return;
}

//----------------------------------------------------------------------------------------------------------------------------//

class Node // Node of the Tree
{
    int data;
    Node *lchild;
    Node *rchild;

public:
    friend class Tree;
    Node()
    {
        lchild = NULL;
        rchild = NULL;
    }
    Node(int d)
    {
        data = d;
        lchild = NULL;
        rchild = NULL;
    }
};

//----------------------------------------------------------------------------------------------------------------------------//

class Tree // Binary Tree
{
    Node *root;
    Node *maketree();

public:
    Tree()
    {
        root = NULL;
    }
    void create()
    {
        root = maketree();
    }
    Node *getroot()
    {
        return root;
    }
    void setroot(Node *p)
    {
        root = p;
    }

    /*--------------TRAVERSALS--------------*/
    void preorder_recur(Node *root)
    {
        if (root != NULL)
        {
            cout << root->data << " ";
            preorder_recur(root->lchild);
            preorder_recur(root->rchild);
        }
    }
    void inorder_recur(Node *root)
    {
        if (root != NULL)
        {
            inorder_recur(root->lchild);
            cout << root->data << " ";
            inorder_recur(root->rchild);
        }
    }
    void postorder_recur(Node *root)
    {
        if (root != NULL)
        {
            postorder_recur(root->lchild);
            postorder_recur(root->rchild);
            cout << root->data << " ";
        }
    }
    void preorder_nrecur(Node *root)
    {

        if (root == NULL)
            return;

        Stack<Node *> s1;
        Node *curr = root;
        while (!s1.isEmpty() || curr != NULL)
        {
            while (curr != NULL)
            {
                cout << curr->data << " ";
                if (curr->rchild)
                    s1.push(curr->rchild);

                curr = curr->lchild;
            }

            if (s1.isEmpty() == false)
            {
                curr = s1.st[s1.top];
                s1.pop();
            }
        }
    }

    void inorder_nrecur(Node *root)
    {
        Stack<Node *> s;
        Node *curr = root;
        while (curr != NULL || s.isEmpty() == false)
        {
            while (curr != NULL)
            {
                s.push(curr);
                curr = curr->lchild;
            }
            curr = s.st[s.top];
            s.pop();
            cout << curr->data << " ";
            curr = curr->rchild;
        }
    }

    void postorder_nrecur(Node *root)
    {

        if (root == NULL)
            return;
        Stack<Node *> s1, s2;
        s1.push(root);
        Node *node;
        while (!s1.isEmpty())
        {
            node = s1.st[s1.top];
            s1.pop();
            s2.push(node);
            if (node->lchild)
                s1.push(node->lchild);
            if (node->rchild)
                s1.push(node->rchild);
        }
        while (!s2.isEmpty())
        {
            node = s2.st[s2.top];
            s2.pop();
            cout << node->data << " ";
        }
    }

    void traversal()
    {
        char c;
        do
        {
            int a;
            cout << "Traversal Techniques:\n 1.Preorder \n 2.Postorder \n 3.Inorder \n";
            cout << "Enter choice" << endl;
            cin >> a;
            if (a == 1)
            {
                cout << "Recursive Method (Preorder): ";
                preorder_recur(root);
                cout << endl;
                cout << "Iterative Method (Preorder): ";
                preorder_nrecur(root);
                cout << endl;
            }
            if (a == 2)
            {
                cout << "Recursive Method (Postorder): ";
                postorder_recur(root);
                cout << endl;
                cout << "Iterative Method (Postorder): ";
                postorder_nrecur(root);
                cout << endl;
            }
            if (a == 3)
            {
                cout << "Recursive Method (Inorder): ";
                inorder_recur(root);
                cout << endl;
                cout << "Iterative Method (Inorder): ";
                inorder_nrecur(root);
                cout << endl;
            }

            cout << "Do you want to continue?(y/n)" << endl;
            cin >> c;

        } while (c == 'y');
    }

    /*----------MIRROR IMAGE----------*/
    void mirror(Node *p)
    {
        if (p == NULL)
        {
            return;
        }
        else
        {
            mirror(p->lchild);
            mirror(p->lchild);
            Node *temp = p->lchild;
            p->lchild = p->rchild;
            p->rchild = temp;
        }
    }

    /*------------COPY TREE------------*/
    Node *copytree(Node *p)
    {
        Node *cnode = NULL;
        if (p != NULL)
        {
            cnode = new Node(p->data);
            cnode->lchild = copytree(p->lchild);
            cnode->rchild = copytree(p->rchild);
        }
        return cnode;
    }
    
    /*------------DELETE TREE------------*/
    void deltree(Node *p)
    {
        if (p != NULL)
        {
            deltree(p->lchild);
            deltree(p->rchild);
            delete p;
        }
    }

    /*------------HEIGHT OF THE TREE------------*/
    int height(Node *p)
    {
        int lh, rh;
        if (p == NULL)
        {
            return 0;
        }
        else
        {
            lh = height(p->lchild);
            rh = height(p->rchild);
        }
        return (1 + max(lh, rh));
    }
    int height2()
    {
        Queue<Node *> q;
        q.push(root);
        int ht = -1;
        while (!q.empty())
        {
            int node_count = q.size();
            while (node_count > 0)
            {
                Node *temp = q.front1();
                q.pop();
                if (temp->lchild != NULL)
                {
                    q.push(temp->lchild);
                }
                if (temp->rchild != NULL)
                {
                    q.push(temp->rchild);
                }
                node_count--;
            }
            ht++;
        }
        return ht;
    }

    /*------------LEAF NODES AND INTERNAL NODES------------*/
    int leafcount(Node *p)
    {

        if (p == NULL)
        {
            return 0;
        }
        if (p->lchild == NULL && p->rchild == NULL)
        {
            return 1;
        }
        else
        {
            return leafcount(p->lchild) + leafcount(p->rchild);
        }
    }

    void node_count(Node *p, int &t)
    {
        if (p != NULL)
        {
            t++;
            node_count(p->lchild, t);
            node_count(p->rchild, t);
        }
    }
};

Node *Tree::maketree()
{
    Node *temp;
    char ch;
    temp = new Node;
    cout << "Enter data:" << endl;
    cin >> temp->data;
    cout << "Enter Right Child for " << temp->data << "? (y/n)" << endl;
    cin >> ch;
    if (ch == 'y')
    {
        temp->rchild = maketree();
    }
    cout << "Enter Left Child for " << temp->data << "? (y/n)" << endl;
    cin >> ch;
    if (ch == 'y')
    {
        temp->lchild = maketree();
    }
    return temp;
}

//----------------------------------------------------------------------------------------------------------------------------//

int main()
{
    Tree t1;
    t1.create();
    cout << "Tree Creation Success" << endl;
    t1.traversal();
    cout << endl;

    int a = t1.height(t1.getroot());
    cout << "Height (Recursive):" << a - 1 << endl;

    int b = t1.height2();
    cout << "Height (Iterative):" << b << endl;

    t1.mirror(t1.getroot());
    cout << "Mirror Image Success" << endl;
    t1.traversal();
    cout << endl;

    int lc = t1.leafcount(t1.getroot());
    cout << "No. Of Leaf Nodes: " << lc << endl;

    int nodecount = 0;
    t1.node_count(t1.getroot(), nodecount);
    cout << "No. Of Internal Nodes: " << (nodecount - lc) << endl;

    Tree t2;
    Node *t = t1.copytree(t1.getroot());
    t2.setroot(t);
    cout << "Copy Tree Success" << endl;
    t2.traversal();
    cout << endl;

    t2.deltree(t2.getroot());
    t2.setroot(NULL);
    cout << "Delete Tree Success" << endl;
    t2.traversal();


    return 0;
}
//----------------------------------------------------------------------------------------------------------------------------//

