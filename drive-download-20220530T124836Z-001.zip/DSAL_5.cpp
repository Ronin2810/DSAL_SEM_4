#include <iostream>
using namespace std;
#define SIZE 13

class Node
{
    friend class HT;
    string key;
    string value;
    Node *next;

public:
    Node(string k = "", string v = "")
    {
        key = k;
        value = v;
        next = NULL;
    }
};

class HT
{
    friend class Node;
    Node *ht[SIZE];

public:
    HT()
    {
        for (int i = 0; i < SIZE; i++)
        {
            ht[i] = NULL;
        }
    }
    void printll(int i)
    {
        Node *temp = ht[i];
        while (temp != NULL)
        {
            cout << temp->key << "->";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    void print()
    {
        cout << "--------------------------------" << endl;
        cout << "INDEX\tVALUES" << endl;
        cout << "--------------------------------" << endl;
        for (int i = 0; i < SIZE; i++)
        {
            cout << i << ":\t";
            printll(i);
        }
        cout << "--------------------------------" << endl;
    }
    int getsum(string key)
    {
        int sum = 0;
        for (int i = 0; i < key.length(); i++)
        {
            sum += key[i];
        }
        return sum;
    }
    int hash(string key)
    {
        int inp = getsum(key);
        return (inp % SIZE);
    }

    void insert(string k, string v)
    {
        Node *tp = new Node(k, v);
        int index = hash(k);
        if (ht[index] == NULL)
        {
            ht[index] = tp;
        }
        else
        {
            Node *temp = ht[index];
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = tp;
        }
    }
    Node *find(string k, int flag)
    {
        int ind = hash(k);
        Node *temp = ht[ind];
        while (temp != NULL)
        {
            if (temp->key == k)
            {
                if (flag == 0)
                {
                    cout << "FOUND!!" << endl;
                    cout<<"Key: "<<temp->key<<endl;
                    cout<<"Value: "<<temp->value<<endl;
                }

                return temp;
            }
            else
            {
                temp = temp->next;
            }
        }
        if (flag == 0)
        {
            cout << "NOT FOUND!!" << endl;
        }

        return NULL;
    }
    void del(string k)
    {
        int ind = hash(k);
        Node *temp = find(k, 1);
        Node *temp1 = ht[ind];
        if (temp1 == temp)
        {
            ht[ind] = temp->next;
            delete temp;
            return;
        }
        else
        {
            while (temp1->next != temp)
            {
                temp1 = temp1->next;
            }
            temp1->next = temp->next;
            temp->next = NULL;
            delete temp;
        }
    }
};

int main()
{
    HT t1;
    t1.insert("aditya", "1");
    t1.insert("adia", "2");
    t1.insert("aita", "3");
    t1.insert("dita", "4");
    t1.insert("itya", "5");
    t1.insert("tyaa", "6");
    t1.insert("yat", "7");
    t1.insert("dati", "8");
    t1.insert("ada", "9");
    t1.insert("adwa", "10");
    t1.print();
    t1.find("ada",0);
    t1.del("ada");
    t1.find("ada",0);
    t1.print();

    return 0;
}