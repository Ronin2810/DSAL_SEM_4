/*A Dictionary stores keywords and its meanings. Provide facility for adding new
keywords, deleting keywords, updating values of any entry. Provide facility to
display whole data sorted in ascending/ Descending order. Also find how many
maximum comparisons may require for finding any keyword. Use Binary Search
Tree for implementation.*/

#include <iostream>
using namespace std;

class Node
{
    string word;
    string meaning;
    Node *lchild;
    Node *rchild;

public:
    friend class BST;
    Node()
    {
        word = "";
        meaning = "";
        lchild = NULL;
        rchild = NULL;
    }
    Node(string a, string b)
    {
        word = a;
        meaning = b;
        lchild = NULL;
        rchild = NULL;
    }
};

class BST
{

    Node *root;

public:
    BST()
    {
        root = NULL;
    }
    void setroot(Node *p)
    {
        root = p;
    }
    Node *getroot()
    {
        return root;
    }
    void searchBST(string key, Node *&loc, Node *&par)
    {
        if (root == NULL)
        {
            // cout<<"Empty BST"<<endl;
            loc = NULL;
            par = NULL;
            return;
        }
        Node *ptr = root;
        while (ptr != NULL)
        {
            if (key == ptr->word)
            {
                loc = ptr;
                // cout<<"Parent:"<<par->word<<endl
                // cout<<"Location:"<<loc->word<<endl
                return;
            }
            else if (key < ptr->word)
            {
                par = ptr;
                ptr = ptr->lchild;
            }
            else
            {
                par = ptr;
                ptr = ptr->rchild;
            }
        }

        if (loc == NULL)
        {
            // cout<<"Not Found";
        }
    }

    void insertBST(string key, string mean)
    {
        Node *loc = NULL;
        Node *par = NULL;
        searchBST(key, loc, par);
        if (loc != NULL)
        {
            cout << "Node Already Exists" << endl;
            return;
        }
        Node *n = new Node();
        n->word = key;
        n->meaning = mean;
        if (par == NULL)
        {
            root = n;
            return;
        }
        else if (n->word < par->word)
        {
            par->lchild = n;
            return;
        }
        else
        {
            par->rchild = n;
            return;
        }
    }

    void ascend(Node *root)
    {

        if (root != NULL)
        {
            ascend(root->lchild);
            cout << root->word << ":" << root->meaning << endl;
            ascend(root->rchild);
        }
    }

    void descend(Node *root)
    {
        if (root != NULL)
        {
            descend(root->rchild);
            cout << root->word << ":" << root->meaning << endl;
            descend(root->lchild);
        }
    }

    void del1(string key)
    {
        Node *loc = NULL;
        Node *par = NULL;
        searchBST(key, loc, par);
        Node *child;
        if (loc->lchild == NULL && loc->rchild == NULL)
        {
            child = NULL;
        }
        else if (loc->lchild != NULL)
        {
            child = loc->lchild;
        }
        else
        {
            child = loc->rchild;
        }

        if (par != NULL)
        {
            if (loc = par->lchild)
            {
                par->lchild = child;
            }
            else
            {
                par->rchild = child;
            }
        }
        else
        {
            root = child;
        }
    }
    void del2(string key)
    {
        Node*loc=NULL;
        Node*par=NULL;

        searchBST(key,loc,par);
        Node*ptr1;
        Node*ptr2;
        ptr1=loc;
        ptr2=loc->rchild;

        while (ptr2->lchild!=NULL)
        {
            ptr1=ptr2;
            ptr2=ptr2->lchild;
        }
        loc->word= ptr2->word;
        loc->meaning= ptr2->meaning;
        
        del1(ptr2->word);


    }
    void deleteBST(string key){
        Node*loc=NULL;
        Node*par=NULL;
        searchBST(key,loc,par);
        if (loc->lchild!=NULL && loc->rchild!=NULL)
        {
            del2(key);
        }
        else
        {
            del1(key);
        }

    }
    void update(string key){
        Node*loc=NULL;
        Node*par=NULL;
        searchBST(key,loc,par);
        string nmean;
        cout<<"Update Meaning:"<<endl;
        cin>>nmean;
        loc->meaning= nmean;
    }
};

int main()
{
    BST t1;
    t1.insertBST("Ashutosh", "");
    t1.insertBST("Avishkar", "");
    t1.insertBST("Rujul", "");
    t1.insertBST("Vedant", "");
    t1.insertBST("Sarthak", "");
    t1.insertBST("Vishwajit", "");
    cout << "Ascending: " << endl;
    t1.ascend(t1.getroot());
    cout << endl;
    cout << "Descending: " << endl;
    t1.descend(t1.getroot());

    t1.update("Sarthak");
    cout << "Ascending: " << endl;
    t1.ascend(t1.getroot());
    cout << endl;

    t1.deleteBST("Sarthak");
    cout << "Ascending: " << endl;
    t1.ascend(t1.getroot());
    cout << endl;

    
    return 0;
}